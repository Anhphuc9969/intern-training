import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import java.util.Arrays;
public class StreamEx {

    // foreach operations helps iterate the elements of the Stream
    public static void main(String[] args) {
//        List<Integer>list= Stream.iterate(1, count -> count + 1) //
//                .filter(number -> number % 3 == 0) //
//                .limit(6) //
//                .collect(Collectors.toList());
//
//        System.out.println(list);
        //
//        Stream.iterate(1, count -> count + 1) //
//                .filter(number -> number % 3 == 0) //
//                .limit(6) //
//                .forEach(System.out::println);
        //

//        List<Integer> data = Arrays.asList(2, 3, 5, 4, 6);
//
//        long count = data.stream().filter(num -> num % 3 == 0).count();
//        System.out.println("Count = " + count);
    }
}